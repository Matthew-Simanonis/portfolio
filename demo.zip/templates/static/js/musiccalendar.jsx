import ReactDOM from 'react-dom';
import React from "react";
//Import App
import App from "./musiccalendar"

// Append App to musiccalnedar.html

ReactDOM.render(<App />, document.querySelector("#content"));