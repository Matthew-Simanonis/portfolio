import ReactDOM from 'react-dom';
import React from "react";
//Import App
import App from "./projects"

// Append App to projects.html

ReactDOM.render(<App />, document.querySelector("#content"));