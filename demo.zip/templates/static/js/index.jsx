import ReactDOM from 'react-dom';
import React from "react";
//Import App
import App from "./index"

// Append App to index.html

ReactDOM.render(<App />, document.querySelector("#content"));