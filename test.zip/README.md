# Matthew Simanonis' Portfolio

Hello, My name is Matthew Simanonis. This is my portfolio. It is made with React.Js and a Flask backend 

It is currently hosted on Amazon Web Services at Matthew-Simanonis.com

I designed and created the website from scratch, along with all of the projects linked. 

It is still a work in progress