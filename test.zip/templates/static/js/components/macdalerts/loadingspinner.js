import React, { useState, useEffect } from 'react';

const LoadingSpinner = () => {
    return(
        <div className='loading-spinner'>
            Loading...
        </div>
    )
}

export default LoadingSpinner